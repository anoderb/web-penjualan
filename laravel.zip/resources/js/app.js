// import './bootstrap';

import 'select2/dist/js/select2.min';
import 'select2/dist/css/select2.min.css';

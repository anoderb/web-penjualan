<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-left mb-0"><?php echo e($title); ?></h2>
                            <div class="breadcrumb-wrapper col-12">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active"><?php echo e($title); ?>

                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <section id="basic-datatable">
                    <?php if(session('success') || session('error')): ?>
                        <div class="alert  alert-<?php echo e(session('success') ? 'success' : 'danger'); ?> alert-dismissible fade show" role="alert">
                            <p class="mb-0"><?php echo e(session('success') ? session('success') : session('error')); ?></p>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true"><i class="feather icon-x-circle"></i></span>
                            </button>
                        </div>
                    <?php endif; ?>

                    
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">First Menu</h4>
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#firstmenu_createModal"><i class="feather icon-plus"></i>&nbsp; Add First Menu</button>
                                    <?php echo $__env->make('menu.V_menu_create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <div class="card-content">
                                    <div class="card-body card-dashboard">
                                        <div class="table-responsive">
                                            <table class="table zero-configuration">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>First Menu Name</th>
                                                        <th>First Menu Link</th>
                                                        <th>First Menu Icon</th>
                                                        <th>Created & Updated</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i = 1; ?>
                                                    <?php $__currentLoopData = $firstmenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firstmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td class="align-top"><?php echo e($i++); ?></td>
                                                            <td class="text-nowrap align-top"><?php echo e($firstmenu->firstmenu_name); ?></td>
                                                            <td class="text-nowrap align-top"><?php echo e($firstmenu->firstmenu_link); ?></td>
                                                            <td class="text-nowrap align-top"><?php echo e($firstmenu->firstmenu_icon); ?></td>
                                                            <td class="text-nowrap align-top">
                                                                <div>Created: <?php echo e($firstmenu->created_at); ?> <?php echo e($firstmenu->created_by ? '(' . $firstmenu->created_by . ')' : ''); ?></div>
                                                                <div>Updated: <?php echo e($firstmenu->updated_at); ?> <?php echo e($firstmenu->updated_by ? '(' . $firstmenu->updated_by . ')' : ''); ?></div>
                                                            </td>
                                                            <td class="align-top btn-group">
                                                                <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#firstmenu_editModal<?php echo e($firstmenu->id_firstmenu); ?>"><i class="feather icon-edit"></i></button>
                                                                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#firstmenu_deletetModal<?php echo e($firstmenu->id_firstmenu); ?>"><i class="feather icon-trash"></i></button>
                                                            </td>
                                                            <?php echo $__env->make('menu.V_menu_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                            <?php echo $__env->make('menu.V_menu_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Second Menu</h4>
                                    <button type="button" class="btn btn-primary btn_secondmenu" data-toggle="modal" data-target="#secondmenu_createModal"><i class="feather icon-plus"></i>&nbsp; Add Second Menu</button>
                                    <?php echo $__env->make('menu.V_menu_create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <div class="card-content">
                                    <div class="card-body card-dashboard">
                                        <div class="table-responsive">
                                            <table class="table zero-configuration">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>First Menu Name</th>
                                                        <th>Second Menu Name</th>
                                                        <th>Second Menu Link</th>
                                                        <th>Second Menu Icon</th>
                                                        <th>Created & Updated</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i = 1; ?>
                                                    <?php $__currentLoopData = $secondmenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td class="align-top"><?php echo e($i++); ?></td>
                                                            <td class="text-nowrap align-top"><?php echo e($secondmenu->firstmenu_name); ?></td>
                                                            <td class="text-nowrap align-top"><?php echo e($secondmenu->secondmenu_name); ?></td>
                                                            <td class="text-nowrap align-top"><?php echo e($secondmenu->secondmenu_link); ?></td>
                                                            <td class="text-nowrap align-top"><?php echo e($secondmenu->secondmenu_icon); ?></td>
                                                            <td class="text-nowrap align-top">
                                                                <div>Created: <?php echo e($secondmenu->created_at); ?> <?php echo e($secondmenu->created_by ? '(' . $secondmenu->created_by . ')' : ''); ?></div>
                                                                <div>Updated: <?php echo e($secondmenu->updated_at); ?> <?php echo e($secondmenu->updated_by ? '(' . $secondmenu->updated_by . ')' : ''); ?></div>
                                                            </td>
                                                            <td class="align-top btn-group">
                                                                <button type="button" class="btn btn-warning btn_secondmenu" data-id="<?php echo e($secondmenu->id_firstmenu); ?>" data-toggle="modal" data-target="#secondmenu_editModal<?php echo e($secondmenu->id_secondmenu); ?>"><i class="feather icon-edit"></i></button>
                                                                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#secondmenu_deletetModal<?php echo e($secondmenu->id_secondmenu); ?>"><i class="feather icon-trash"></i></button>
                                                            </td>
                                                            <?php echo $__env->make('menu.V_menu_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                            <?php echo $__env->make('menu.V_menu_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Third Menu</h4>
                                    <button type="button" class="btn btn-primary btn_thirdmenu" data-toggle="modal" data-target="#thirdmenu_createModal"><i class="feather icon-plus"></i>&nbsp; Add Third Menu</button>
                                    <?php echo $__env->make('menu.V_menu_create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <div class="card-content">
                                    <div class="card-body card-dashboard">
                                        <div class="table-responsive">
                                            <table class="table zero-configuration">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Second Menu Name</th>
                                                        <th>Third Menu Name</th>
                                                        <th>Third Menu Link</th>
                                                        <th>Third Menu Icon</th>
                                                        <th>Times</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i = 1; ?>
                                                    <?php $__currentLoopData = $thirdmenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thirdmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td class="align-top"><?php echo e($i++); ?></td>
                                                            <td class="text-nowrap align-top"><?php echo e($thirdmenu->secondmenu_name); ?></td>
                                                            <td class="text-nowrap align-top"><?php echo e($thirdmenu->thirdmenu_name); ?></td>
                                                            <td class="text-nowrap align-top"><?php echo e($thirdmenu->thirdmenu_link); ?></td>
                                                            <td class="text-nowrap align-top"><?php echo e($thirdmenu->thirdmenu_icon); ?></td>
                                                            <td class="text-nowrap align-top">
                                                                <div>Created: <?php echo e($thirdmenu->created_at); ?> <?php echo e($thirdmenu->created_by ? '(' . $thirdmenu->created_by . ')' : ''); ?></div>
                                                                <div>Updated: <?php echo e($thirdmenu->updated_at); ?> <?php echo e($thirdmenu->updated_by ? '(' . $thirdmenu->updated_by . ')' : ''); ?></div>
                                                            </td>
                                                            <td class="align-top btn-group">
                                                                <button type="button" class="btn btn-warning btn_thirdmenu" data-id="<?php echo e($thirdmenu->id_secondmenu); ?>" data-toggle="modal" data-target="#thirdmenu_editModal<?php echo e($thirdmenu->id_thirdmenu); ?>"><i class="feather icon-edit"></i></button>
                                                                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#thirdmenu_deletetModal<?php echo e($thirdmenu->id_thirdmenu); ?>"><i class="feather icon-trash"></i></button>
                                                            </td>
                                                            <?php echo $__env->make('menu.V_menu_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                            <?php echo $__env->make('menu.V_menu_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Fourth Menu</h4>
                                    <button type="button" class="btn btn-primary btn_fourthmenu" data-toggle="modal" data-target="#fourthmenu_createModal"><i class="feather icon-plus"></i>&nbsp; Add Fourth Menu</button>
                                    <?php echo $__env->make('menu.V_menu_create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <div class="card-content">
                                    <div class="card-body card-dashboard">
                                        <div class="table-responsive">
                                            <table class="table zero-configuration">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Third Menu Name</th>
                                                        <th>Fourth Menu Name</th>
                                                        <th>Fourth Menu Link</th>
                                                        <th>Fourth Menu Icon</th>
                                                        <th>Created & Updated</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i = 1; ?>
                                                    <?php $__currentLoopData = $fourthmenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fourthmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td class="align-top"><?php echo e($i++); ?></td>
                                                            <td class="text-nowrap align-top"><?php echo e($fourthmenu->thirdmenu_name); ?></td>
                                                            <td class="text-nowrap align-top"><?php echo e($fourthmenu->fourthmenu_name); ?></td>
                                                            <td class="text-nowrap align-top"><?php echo e($fourthmenu->fourthmenu_link); ?></td>
                                                            <td class="text-nowrap align-top"><?php echo e($fourthmenu->fourthmenu_icon); ?></td>
                                                            <td class="text-nowrap align-top">
                                                                <div>Created: <?php echo e($fourthmenu->created_at); ?> <?php echo e($fourthmenu->created_by ? '(' . $fourthmenu->created_by . ')' : ''); ?></div>
                                                                <div>Updated: <?php echo e($fourthmenu->updated_at); ?> <?php echo e($fourthmenu->updated_by ? '(' . $fourthmenu->updated_by . ')' : ''); ?></div>
                                                            </td>
                                                            <td class="align-top btn-group">
                                                                <button type="button" class="btn btn-warning btn_fourthmenu" data-id="<?php echo e($fourthmenu->id_thirdmenu); ?>" data-toggle="modal" data-target="#fourthmenu_editModal<?php echo e($fourthmenu->id_fourthmenu); ?>"><i
                                                                        class="feather icon-edit"></i></button>
                                                                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#fourthmenu_deletetModal<?php echo e($fourthmenu->id_fourthmenu); ?>"><i class="feather icon-trash"></i></button>
                                                            </td>
                                                            <?php echo $__env->make('menu.V_menu_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                            <?php echo $__env->make('menu.V_menu_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('.btn_secondmenu').on('click', function() {
                var buttonId = $(this).data('id');
                $.ajax({
                    url: "<?php echo e(route('menu_firstmenu_list')); ?>",
                    method: "GET",
                    success: function(response) {
                        $('.id_firstmenu').empty();
                        $('.id_firstmenu').append('<option value="">- select -</option>');
                        $.each(response, function(index, item) {
                            var selected = (item.id_firstmenu == buttonId) ? 'selected' : '';
                            $('.id_firstmenu').append('<option value="' + item.id_firstmenu + '" ' + selected + '>' + item.firstmenu_name + '</option>');
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });

            $('.btn_thirdmenu').on('click', function() {
                var buttonId = $(this).data('id');
                $.ajax({
                    url: "<?php echo e(route('menu_secondmenu_list')); ?>",
                    method: "GET",
                    success: function(response) {
                        $('.id_secondmenu').empty();
                        $('.id_secondmenu').append('<option value="">- select -</option>');
                        $.each(response, function(index, item) {
                            var selected = (item.id_secondmenu == buttonId) ? 'selected' : '';
                            $('.id_secondmenu').append('<option value="' + item.id_secondmenu + '" ' + selected + '>' + item.secondmenu_name + '</option>');
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });

            $('.btn_fourthmenu').on('click', function() {
                var buttonId = $(this).data('id');
                $.ajax({
                    url: "<?php echo e(route('menu_thirdmenu_list')); ?>",
                    method: "GET",
                    success: function(response) {
                        $('.id_thirdmenu').empty();
                        $('.id_thirdmenu').append('<option value="">- select -</option>');
                        $.each(response, function(index, item) {
                            var selected = (item.id_thirdmenu == buttonId) ? 'selected' : '';
                            $('.id_thirdmenu').append('<option value="' + item.id_thirdmenu + '" ' + selected + '>' + item.thirdmenu_name + '</option>');
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Warsi\web taskschedule\resources\views/menu/V_menu.blade.php ENDPATH**/ ?>
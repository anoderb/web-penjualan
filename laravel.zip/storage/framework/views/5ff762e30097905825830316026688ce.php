<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-left mb-0"><?php echo e($title); ?></h2>
                            <div class="breadcrumb-wrapper col-12">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active"><?php echo e($title); ?>

                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <section id="basic-datatable">
                    <?php if(session('success') || session('error')): ?>
                        <div class="alert  alert-<?php echo e(session('success') ? 'success' : 'danger'); ?> alert-dismissible fade show" role="alert">
                            <p class="mb-0"><?php echo e(session('success') ? session('success') : session('error')); ?></p>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true"><i class="feather icon-x-circle"></i></span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createModal"><i class="feather icon-plus"></i>&nbsp; Add New</button>
                                    <?php echo $__env->make('level.V_level_create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <div class="card-content">
                                    <div class="card-body card-dashboard">
                                        <div class="table-responsive">
                                            <table class="table zero-configuration">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Level Name</th>
                                                        <th>Created & Updated</th>
                                                        <th>Access Menu</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i = 1; ?>
                                                    <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td class="align-top"><?php echo e($i++); ?></td>
                                                            <td class="text-nowrap align-top">
                                                                <?php echo e($level->level_name); ?>

                                                            </td>
                                                            <td class="text-nowrap align-top">
                                                                <div><span class="font-weight-bold">Created:</span> <?php echo e($level->created_at); ?> <?php echo e($level->created_by ? '(' . $level->created_by . ')' : ''); ?></div>
                                                                <div><span class="font-weight-bold">Updated:</span> <?php echo e($level->updated_at); ?> <?php echo e($level->updated_by ? '(' . $level->updated_by . ')' : ''); ?></div>
                                                            </td>
                                                            <td>
                                                                <a href="<?php echo e(url('/accessmenu/create/' . $level->id_level)); ?>" class="btn btn-warning"><i class="feather icon-edit"></i></a>
                                                            </td>
                                                            <td class="align-top btn-group">
                                                                <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#editModal<?php echo e($level->id_level); ?>"><i class="feather icon-edit"></i></button>
                                                                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deletetModal<?php echo e($level->id_level); ?>"><i class="feather icon-trash"></i></button>
                                                            </td>
                                                            <?php echo $__env->make('level.V_level_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                            <?php echo $__env->make('level.V_level_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\web dgift\resources\views/level/V_level.blade.php ENDPATH**/ ?>
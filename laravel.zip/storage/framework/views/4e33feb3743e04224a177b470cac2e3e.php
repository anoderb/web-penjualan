<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(url('/')); ?>" class="brand-link bg-danger">
        <span class="brand-text font-weight-light font-weight-bold text-uppercase"><?php echo e(config('app.name', 'App Name')); ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="<?php echo e(asset('/')); ?>adminlte3-template/dist/img/avatar2.png" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block"><?php echo e(Auth::user()->name); ?> (<?php echo e(Auth::user()->level->level_name); ?>)</a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <!-- Add icons to the links using the .nav-icon class with font-awesome or any other icon font library -->
                <li class="nav-item">
                    <a href="<?php echo e(url('home')); ?>" class="nav-link <?php if(Request::is('home') || Request::is('home/*')): ?> active <?php endif; ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dashboard
                        </p>
                    </a>
                </li>

                <li class="nav-header"><?php echo e(Auth::user()->level->level_name); ?></li>

                <?php $__currentLoopData = $menu_byidlevel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firstmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php
                        $firstMenuActive = false;
                    ?>

                    <?php if(Request::is($firstmenu['link']) || Request::is($firstmenu['link'] . '/*')): ?>
                        <?php
                            $firstMenuActive = true;
                        ?>
                    <?php endif; ?>

                    <?php $__currentLoopData = $firstmenu['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Request::is($secondmenu['link']) || Request::is($secondmenu['link'] . '/*')): ?>
                            <?php
                                $firstMenuActive = true;
                            ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <li class="nav-item <?php if($firstMenuActive): ?> menu-open <?php endif; ?>">
                        <a href="<?php echo e(url($firstmenu['link'])); ?>" class="nav-link <?php if($firstMenuActive): ?> active <?php endif; ?>">
                            <i class="nav-icon <?php echo e($firstmenu['icon']); ?>"></i>
                            <p>
                                <?php echo e($firstmenu['name']); ?>

                                <?php if(!empty($firstmenu['children'])): ?>
                                    <i class="fas fa-angle-left right"></i>
                                <?php endif; ?>
                            </p>
                        </a>

                        <?php if(!empty($firstmenu['children'])): ?>
                            <ul class="nav nav-treeview">
                                
                                <?php $__currentLoopData = $firstmenu['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url($secondmenu['link'])); ?>" class="nav-link <?php if(Request::is($secondmenu['link']) || Request::is($secondmenu['link'] . '/*')): ?> active <?php endif; ?>">
                                            <i class="nav-icon <?php echo e($secondmenu['icon']); ?>"></i>
                                            <p><?php echo e($secondmenu['name']); ?></p>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\other\web-penjualan\resources\views/layouts/home/sidebar.blade.php ENDPATH**/ ?>
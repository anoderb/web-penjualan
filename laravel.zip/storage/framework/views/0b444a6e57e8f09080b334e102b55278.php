<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo e($title); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">
                                    Dashboard</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="card">
                    <form action="<?php echo e(route('accessmenu_store', $level->id_level)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="card-header">
                            <h3><?php echo e(!empty($level) ? 'Nama Level: ' . $level->level_name : ''); ?></h3>
                        </div>
                        <div class="card-body card-dashboard">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Menu</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1; ?>
                                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $checked = '';
                                                // Check apakah data menu ini sudah ada di tabel accessmenu
                                                $accessmenu = App\Models\M_accessmenu::where('id_firstmenu', $menu->id_firstmenu)
                                                    ->where('id_secondmenu', $menu->id_secondmenu)
                                                    ->where('id_thirdmenu', $menu->id_thirdmenu)
                                                    ->where('id_fourthmenu', $menu->id_fourthmenu)
                                                    ->where('id_level', $level->id_level)
                                                    ->first();
                                                // Jika data sudah ada, set $checked menjadi 'checked'
                                                if ($accessmenu) {
                                                    $checked = 'checked';
                                                }
                                            ?>
                                            <tr>
                                                <input type="hidden" name="id_level[]" id="id_level" value="<?php echo e($level->id_level); ?>">
                                                <td><?php echo e($i++); ?></td>
                                                <td><button type="button" class="btn btn-primary"><?php echo e(implode(' > ', array_filter([$menu->firstmenu_name, $menu->secondmenu_name, $menu->thirdmenu_name, $menu->fourthmenu_name]))); ?></button></td>
                                                <td>
                                                    <div class="vs-checkbox-con vs-checkbox-primary">
                                                        <input type="checkbox" name="id_menu[]" id="id_menu" value="<?php echo e($menu->id_firstmenu . ',' . $menu->id_secondmenu . ',' . $menu->id_thirdmenu . ',' . $menu->id_fourthmenu); ?>" <?php echo e($checked); ?>>
                                                        <span class="vs-checkbox">
                                                            <span class="vs-checkbox--check">
                                                                <i class="vs-icon feather icon-check"></i>
                                                            </span>
                                                        </span>
                                                        <span class="">Aktif</span>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
                <!-- /.card -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\sourcecode wb penjualan\sourcecode wb penjualan\resources\views/accessmenu/V_accessmenu_edit.blade.php ENDPATH**/ ?>
<div class="modal fade text-left" id="editModal<?php echo e($taskschedule->id_taskschedule); ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel<?php echo e($taskschedule->id_taskschedule); ?>" aria-hidden="true">
    <form action="<?php echo e(route('taskschedule_update', $taskschedule->id_taskschedule)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="modal-dialog modal-dialog-scrollable modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="editModalLabel<?php echo e($taskschedule->id_taskschedule); ?>">Edit Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-3 col-6">
                            <div class="form-group">
                                <label for="image1">Image 1</label>
                                <a id="view_image1" target="blank">
                                    <?php if($taskschedule->image1): ?>
                                        <a href="<?php echo e(asset('/assets/images/taskschedule/' . $taskschedule->image1)); ?>" target="_blank">
                                            <img src="<?php echo e(asset('/assets/images/taskschedule/' . $taskschedule->image1)); ?>" alt="" class="img-thumbnail preview_image1">
                                        </a>
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('/assets/images/taskschedule/default-image.jpg')); ?>" alt="" class="img-thumbnail preview_image1">
                                    <?php endif; ?>
                                </a>
                                <input type="file" name="image1" id="image1" value="" class="form-control image1 <?php $__errorArgs = ['image1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="image/*" autofocus>
                                <?php $__errorArgs = ['image1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="form-group">
                                <label for="image2">Image 2</label>
                                <a id="view_image2" target="blank">
                                    <?php if($taskschedule->image2): ?>
                                        <a href="<?php echo e(asset('/assets/images/taskschedule/' . $taskschedule->image2)); ?>" target="_blank">
                                            <img src="<?php echo e(asset('/assets/images/taskschedule/' . $taskschedule->image2)); ?>" alt="" class="img-thumbnail preview_image2">
                                        </a>
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('/assets/images/taskschedule/default-image.jpg')); ?>" alt="" class="img-thumbnail preview_image2">
                                    <?php endif; ?>
                                </a>
                                <input type="file" name="image2" id="image2" value="" class="form-control image2" accept="image/*">
                            </div>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="form-group">
                                <label for="image3">Image 3</label>
                                <a id="view_image3" target="blank">
                                    <?php if($taskschedule->image3): ?>
                                        <a href="<?php echo e(asset('/assets/images/taskschedule/' . $taskschedule->image3)); ?>" target="_blank">
                                            <img src="<?php echo e(asset('/assets/images/taskschedule/' . $taskschedule->image3)); ?>" alt="" class="img-thumbnail preview_image3">
                                        </a>
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('/assets/images/taskschedule/default-image.jpg')); ?>" alt="" class="img-thumbnail preview_image3">
                                    <?php endif; ?>
                                </a>
                                <input type="file" name="image3" id="image3" value="" class="form-control image3" accept="image/*">
                            </div>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="form-group">
                                <label for="image4">Image 4</label>
                                <a id="view_image4" target="blank">
                                    <?php if($taskschedule->image4): ?>
                                        <a href="<?php echo e(asset('/assets/images/taskschedule/' . $taskschedule->image4)); ?>" target="_blank">
                                            <img src="<?php echo e(asset('/assets/images/taskschedule/' . $taskschedule->image4)); ?>" alt="" class="img-thumbnail preview_image4">
                                        </a>
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('/assets/images/taskschedule/default-image.jpg')); ?>" alt="" class="img-thumbnail preview_image4">
                                    <?php endif; ?>
                                </a>
                                <input type="file" name="image4" id="image4" value="" class="form-control image4" accept="image/*">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="id_program">Program Name</label>
                                <select name="id_program" id="id_program" class="form-control id_program <?php $__errorArgs = ['id_program'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autofocus>
                                    <option value="">- select -</option>
                                    <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($program->id_program); ?>" <?php echo e($program->id_program == $taskschedule->id_program ? 'selected' : ''); ?>><?php echo e($program->program_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['id_program'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="id_module">Module Name</label>
                                <select name="id_module" id="id_module" class="form-control id_module <?php $__errorArgs = ['id_module'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">- select -</option>
                                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($module->id_module); ?>" <?php echo e($module->id_module == $taskschedule->id_module ? 'selected' : ''); ?>><?php echo e($module->module_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['id_module'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="deadline">Deadline</label>
                                <input type="date" name="deadline" id="deadline" value="<?php echo e($taskschedule->deadline); ?>" class="form-control deadline <?php $__errorArgs = ['deadline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['deadline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <?php if(Auth::user()->level->id_level == 1): ?>
                                <div class="form-group">
                                    <label for="id_user">Staf Name</label>
                                    <select name="id_user" id="id_user" class="form-control id_user <?php $__errorArgs = ['id_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autofocus>
                                        <option value="">- select -</option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->id_user); ?>" <?php echo e($user->id_user == $taskschedule->id_user ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['id_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea name="description" id="description" class="form-control description <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30" rows="5" placeholder="Description"><?php echo e($taskschedule->description); ?></textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="change_model">Change Model</label>
                                <div class="d-flex">
                                    <div class="vs-checkbox-con vs-checkbox-primary">
                                        <input type="checkbox" name="change_model" id="change_model" value="1" class="change_model" <?php echo e($taskschedule->change_model == 1 ? 'checked' : ''); ?>>
                                        <span class="vs-checkbox">
                                            <span class="vs-checkbox--check">
                                                <i class="vs-icon feather icon-check"></i>
                                            </span>
                                        </span>
                                    </div>
                                    <input type="text" name="desc_model" id="desc_model" value="<?php echo e($taskschedule->desc_model); ?>" class="form-control desc_model <?php $__errorArgs = ['desc_model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Desc Model">
                                </div>
                                <?php $__errorArgs = ['desc_model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="change_controller">Change Controller</label>
                                <div class="d-flex">
                                    <div class="vs-checkbox-con vs-checkbox-primary">
                                        <input type="checkbox" name="change_controller" id="change_controller" value="1" class="change_controller" <?php echo e($taskschedule->change_controller == 1 ? 'checked' : ''); ?>>
                                        <span class="vs-checkbox">
                                            <span class="vs-checkbox--check">
                                                <i class="vs-icon feather icon-check"></i>
                                            </span>
                                        </span>
                                    </div>
                                    <input type="text" name="desc_controller" id="desc_controller" value="<?php echo e($taskschedule->desc_controller); ?>" class="form-control desc_controller <?php $__errorArgs = ['desc_controller'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Desc Controller">
                                </div>
                                <?php $__errorArgs = ['desc_controller'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="change_view">Change View</label>
                                <div class="d-flex">
                                    <div class="vs-checkbox-con vs-checkbox-primary">
                                        <input type="checkbox" name="change_view" id="change_view" value="1" class="change_view" <?php echo e($taskschedule->change_view == 1 ? 'checked' : ''); ?>>
                                        <span class="vs-checkbox">
                                            <span class="vs-checkbox--check">
                                                <i class="vs-icon feather icon-check"></i>
                                            </span>
                                        </span>
                                    </div>
                                    <input type="text" name="desc_view" id="desc_view" value="<?php echo e($taskschedule->desc_view); ?>" class="form-control desc_view <?php $__errorArgs = ['desc_view'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Desc View">
                                </div>
                                <?php $__errorArgs = ['desc_view'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="change_database">Change Database</label>
                                <div class="d-flex">
                                    <div class="vs-checkbox-con vs-checkbox-primary">
                                        <input type="checkbox" name="change_database" id="change_database" value="1" class="change_database" <?php echo e($taskschedule->change_database == 1 ? 'checked' : ''); ?>>
                                        <span class="vs-checkbox">
                                            <span class="vs-checkbox--check">
                                                <i class="vs-icon feather icon-check"></i>
                                            </span>
                                        </span>
                                    </div>
                                    <input type="text" name="desc_database" id="desc_database" value="<?php echo e($taskschedule->desc_database); ?>" class="form-control desc_database <?php $__errorArgs = ['desc_database'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Desc Database">
                                </div>
                                <?php $__errorArgs = ['desc_database'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="change_assets">Change Assets</label>
                                <div class="d-flex">
                                    <div class="vs-checkbox-con vs-checkbox-primary">
                                        <input type="checkbox" name="change_assets" id="change_assets" value="1" class="change_assets" <?php echo e($taskschedule->change_assets == 1 ? 'checked' : ''); ?>>
                                        <span class="vs-checkbox">
                                            <span class="vs-checkbox--check">
                                                <i class="vs-icon feather icon-check"></i>
                                            </span>
                                        </span>
                                    </div>
                                    <input type="text" name="desc_assets" id="desc_assets" value="<?php echo e($taskschedule->desc_assets); ?>" class="form-control desc_assets <?php $__errorArgs = ['desc_assets'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Desc Assets">
                                </div>
                                <?php $__errorArgs = ['desc_assets'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="change_others">Change Others</label>
                                <div class="d-flex">
                                    <div class="vs-checkbox-con vs-checkbox-primary">
                                        <input type="checkbox" name="change_others" id="change_others" value="1" class="change_others" <?php echo e($taskschedule->change_others == 1 ? 'checked' : ''); ?>>
                                        <span class="vs-checkbox">
                                            <span class="vs-checkbox--check">
                                                <i class="vs-icon feather icon-check"></i>
                                            </span>
                                        </span>
                                    </div>
                                    <input type="text" name="desc_others" id="desc_others" value="<?php echo e($taskschedule->desc_others); ?>" class="form-control desc_others <?php $__errorArgs = ['desc_others'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Desc Others">
                                </div>
                                <?php $__errorArgs = ['desc_others'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="id_status">Status Name</label>
                                <select name="id_status" id="id_status" class="form-control id_status <?php $__errorArgs = ['id_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($status->id_status); ?>" <?php echo e($status->id_status == $taskschedule->id_status ? 'selected' : ''); ?>><?php echo e($status->status_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['id_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-secondary">Reset</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php /**PATH D:\Warsi\web taskschedule\resources\views/taskschedule/V_taskschedule_edit.blade.php ENDPATH**/ ?>
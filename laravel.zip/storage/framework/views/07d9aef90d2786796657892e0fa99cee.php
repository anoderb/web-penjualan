<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo e($title); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/sales')); ?>">
                                    Penjualan</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="no_invoice">No Faktur</label>
                                    <input type="text" name="no_invoice" id="no_invoice" value="<?php echo e($sales->no_invoice); ?>" class="form-control no_invoice" placeholder="No Faktur" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="sales_type">Jenis Penjualan</label>
                                    <input type="text" name="sales_type" id="sales_type" value="<?php echo e($sales->sales_type); ?>" class="form-control sales_type" placeholder="Jenis Penjualan" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="id_customer">Nama Konsumen</label>
                                    <input type="text" name="id_customer" id="id_customer" value="<?php echo e($sales->customer->customer_name); ?>" class="form-control id_customer" placeholder="Nama Konsumen" readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Total</label>
                                    <div class="card bg-success">
                                        <div class="card-body">
                                            <h1>Rp. <?php echo e(number_format($sales->total)); ?></h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr>
                        <?php if(session('success') || session('error')): ?>
                            <div class="alert  alert-<?php echo e(session('success') ? 'success' : 'danger'); ?> alert-dismissible fade show" role="alert">
                                <p class="mb-0"><?php echo e(session('success') ? session('success') : session('error')); ?></p>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true"><i class="feather icon-x-circle"></i></span>
                                </button>
                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('store_sales_detail', $sales->id_sales)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="product_code">Kode Produk</label>
                                        <input type="text" name="product_code" id="product_code" value="<?php echo e(old('product_code')); ?>" class="form-control product_code <?php $__errorArgs = ['product_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <?php $__errorArgs = ['product_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="qty_sale">QTY</label>
                                        <div class="row">
                                            <div class="col-6">
                                                <input type="number" name="qty_sale" id="qty_sale" value="<?php echo e(old('qty_sale')); ?>" class="form-control qty_sale <?php $__errorArgs = ['qty_sale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <?php $__errorArgs = ['qty_sale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-6 text-right">
                                                <button type="submit" class="btn btn-primary">Tambah Penjualan</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                        <br>
                        <div class="table-responsive">
                            <table id="" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode Produk</th>
                                        <th>Satuan</th>
                                        <th>Harga</th>
                                        <th>QTY</th>
                                        <th>Diskon</th>
                                        <th>Sub Total</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $sales_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="align-top"><?php echo e($i++); ?></td>
                                            <td class="text-nowrap align-top">
                                                <?php echo e($sales_detail->product->product_code . ' - ' . $sales_detail->product->product_name); ?>

                                            </td>
                                            <td class="text-nowrap align-top">
                                                <?php echo e($sales_detail->product->unit); ?>

                                            </td>
                                            <td class="text-nowrap align-top">
                                                Rp. <?php echo e(number_format($sales_detail->price_sale)); ?>

                                            </td>
                                            <td class="text-nowrap align-top">
                                                <?php echo e($sales_detail->qty_sale); ?>

                                            </td>
                                            <td class="text-nowrap align-top">
                                                Rp. <?php echo e(number_format($sales_detail->discount_sale)); ?>

                                            </td>
                                            <td class="text-nowrap align-top">
                                                Rp. <?php echo e(number_format($sales_detail->subtotal_sale)); ?>

                                            </td>
                                            <td class="align-top btn-group">
                                                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deletesalesdetailtModal<?php echo e($sales_detail->id_sales_detail); ?>"><i class="fas fa-trash"></i></button>

                                                <div class="modal fade text-left" id="deletesalesdetailtModal<?php echo e($sales_detail->id_sales_detail); ?>" tabindex="-1" role="dialog" aria-labelledby="deletesalesdetailtModalLabel<?php echo e($sales_detail->id_sales_detail); ?>" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-scrollable" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title" id="deletesalesdetailtModalLabel<?php echo e($sales_detail->id_sales_detail); ?>">Hapus Data</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <h5>Apakah Anda yakin ingin menghapus data ini?</h5>
                                                                <p>Jika iya, pilih 'Hapus' untuk menghapus data.</p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <form action="<?php echo e(route('destroy_sales_detail', ['id' => $sales_detail->id_sales_detail, 'id_sales' => $sales->id_sales])); ?>" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button type="submit" class="btn btn-danger">Hapus</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                    <div class="card-footer">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#checkoutModal">Pembayaran</button>
                    </div>
                </div>
                <!-- /.card -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>

    <div class="modal fade" id="checkoutModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Pembayaran</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('update_sales_payment', $sales->id_sales)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="total">Total</label>
                            <input type="text" name="total" id="total" value="<?php echo e($sales->total); ?>" class="form-control total" readonly>
                            <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="payment">Bayar</label>
                            <input type="text" name="payment" id="payment" value="<?php echo e($sales->payment); ?>" class="form-control payment <?php $__errorArgs = ['payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Bayar">
                            <?php $__errorArgs = ['payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="change_money">Kembalian</label>
                            <input type="text" name="change_money" id="change_money" value="<?php echo e($sales->change_money); ?>" class="form-control change_money <?php $__errorArgs = ['change_money'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Kembalian" readonly>
                            <?php $__errorArgs = ['change_money'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Keluar</button>
                        <button type="submit" class="btn btn-primary">Bayar</button>
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            function calculateSubtotal() {
                var total = parseFloat($('#total').val()) || 0;
                var payment = parseFloat($('#payment').val()) || 0;
                var change_money = payment - total;
                $('#change_money').val(change_money);
            }

            // Event listener untuk perubahan pada input harga beli dan kuantitas beli
            $('#total, #payment').on('input', function() {
                calculateSubtotal();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Downloads\joki web penjualan\web penjualan\resources\views/sales/V_sales_edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('style'); ?>
    <style></style>
<?php $__env->stopSection(); ?>

<div class="horizontal-menu-wrapper">
    <div class="header-navbar navbar-expand-sm navbar navbar-horizontal floating-nav navbar-light navbar-without-dd-arrow navbar-shadow menu-border" role="navigation" data-menu="menu-wrapper">
        <div class="navbar-header">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item mr-auto"><a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('/')); ?>assets/images/icon/logo.png" alt="" width="45">
                        <h2 class="brand-text mb-0">DGift Jambi</h2>
                    </a></li>
                <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i class="feather icon-x d-block d-xl-none font-medium-4 primary toggle-icon"></i><i class="toggle-icon feather icon-disc font-medium-4 d-none d-xl-block collapse-toggle-icon primary"
                            data-ticon="icon-disc"></i></a></li>
            </ul>
        </div>
        <!-- Horizontal menu content-->
        <div class="navbar-container main-menu-content" data-menu="menu-container">
            <ul class="nav navbar-nav" id="main-menu-navigation" data-menu="menu-navigation">
                <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="index.html" data-toggle="dropdown"><i class="feather icon-home"></i><span data-i18n="Dashboard">Dashboard</span></a>
                    <ul class="dropdown-menu">
                        <li class="active" data-menu=""><a class="dropdown-item" href="dashboard-analytics.html" data-toggle="dropdown" data-i18n="Analytics"><i class="feather icon-activity"></i>Analytics</a>
                        </li>
                        <li data-menu=""><a class="dropdown-item" href="dashboard-ecommerce.html" data-toggle="dropdown" data-i18n="eCommerce"><i class="feather icon-shopping-cart"></i>eCommerce</a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown"><i class="feather icon-layers"></i><span data-i18n="Apps">Masters</span></a>
                    <ul class="dropdown-menu">
                        <li data-menu=""><a class="dropdown-item" href="<?php echo e(url('/user')); ?>" data-toggle="dropdown" data-i18n="User"><i class="feather icon-user"></i>User</a></li>
                        <li data-menu=""><a class="dropdown-item" href="<?php echo e(url('/category')); ?>" data-toggle="dropdown" data-i18n="User"><i class="feather icon-list"></i>Category</a></li>
                    </ul>
                </li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/product')); ?>"><i class="feather icon-package"></i><span data-i18n="Product">Product</span></a>
                </li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/transaction')); ?>"><i class="feather icon-dollar-sign"></i><span data-i18n="Transaction">Transaction</span></a>
                </li>
            </ul>
        </div>
    </div>
</div>

<?php $__env->startSection('script'); ?>
    <script></script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\User\Desktop\web d gift\resources\views/layouts/home/mainmenu.blade.php ENDPATH**/ ?>
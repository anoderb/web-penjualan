<!DOCTYPE html>
<html class="loading" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-textdirection="ltr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Page')); ?> <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>adminlte3-template/plugins/fontawesome-free/css/all.min.css">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>adminlte3-template/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>adminlte3-template/dist/css/adminlte.min.css">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/')); ?>assets/css/my-style.css">

    

</head>

<body class="hold-transition login-page">
    <div id="app">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- jQuery -->
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/dist/js/adminlte.min.js"></script>

    <script src="<?php echo e(asset('/')); ?>assets/js/my-script.js"></script>

</body>

</html>
<?php /**PATH C:\sourcecode wb penjualan\sourcecode wb penjualan\resources\views/layouts/auth/app.blade.php ENDPATH**/ ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-left mb-0"><?php echo e($title); ?></h2>
                            <div class="breadcrumb-wrapper col-12">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(url('/level')); ?>">Level</a>
                                    </li>
                                    <li class="breadcrumb-item active"><?php echo e($title); ?>

                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <section id="basic-datatable">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-content">
                                    <form action="<?php echo e(route('accessmenu_store', $level->id_level)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('POST'); ?>
                                        <div class="card-header">
                                            <h3><?php echo e(!empty($level) ? 'Level Name: ' . $level->level_name : ''); ?></h3>
                                        </div>
                                        <div class="card-body card-dashboard">
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th>No</th>
                                                            <th>Menu</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $i = 1; ?>
                                                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                                $checked = '';
                                                                // Check apakah data menu ini sudah ada di tabel accessmenu
                                                                $accessmenu = App\Models\M_accessmenu::where('id_firstmenu', $menu->id_firstmenu)
                                                                    ->where('id_secondmenu', $menu->id_secondmenu)
                                                                    ->where('id_thirdmenu', $menu->id_thirdmenu)
                                                                    ->where('id_fourthmenu', $menu->id_fourthmenu)
                                                                    ->where('id_level', $level->id_level)
                                                                    ->first();
                                                                // Jika data sudah ada, set $checked menjadi 'checked'
                                                                if ($accessmenu) {
                                                                    $checked = 'checked';
                                                                }
                                                            ?>
                                                            <tr>
                                                                <input type="hidden" name="id_level[]" id="id_level" value="<?php echo e($level->id_level); ?>">
                                                                <td><?php echo e($i++); ?></td>
                                                                <td><?php echo e(implode(' > ', array_filter([$menu->firstmenu_name, $menu->secondmenu_name, $menu->thirdmenu_name, $menu->fourthmenu_name]))); ?></td>
                                                                <td> <input type="checkbox" name="id_menu[]" id="id_menu" value="<?php echo e($menu->id_firstmenu . ',' . $menu->id_secondmenu . ',' . $menu->id_thirdmenu . ',' . $menu->id_fourthmenu); ?>" <?php echo e($checked); ?>></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <button type="submit" class="btn btn-primary">Save</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\web dgift\resources\views/accessmenu/V_accessmenu_edit.blade.php ENDPATH**/ ?>
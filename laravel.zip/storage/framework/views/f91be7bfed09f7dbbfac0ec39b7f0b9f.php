<div class="horizontal-menu-wrapper">
    <div class="header-navbar navbar-expand-sm navbar navbar-horizontal floating-nav navbar-light navbar-without-dd-arrow navbar-shadow menu-border" role="navigation" data-menu="menu-wrapper">
        <div class="navbar-header">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item mr-auto"><a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('/')); ?>assets/images/application/logo.jpg" alt="" width="45">
                        <h2 class="brand-text mb-0"><?php echo e(config('app.name', 'TITLE')); ?></h2>
                    </a></li>
                <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i class="feather icon-x d-block d-xl-none font-medium-4 primary toggle-icon"></i><i class="toggle-icon feather icon-disc font-medium-4 d-none d-xl-block collapse-toggle-icon primary"
                            data-ticon="icon-disc"></i></a></li>
            </ul>
        </div>

        <!-- Horizontal menu content-->
        <div class="navbar-container main-menu-content" data-menu="menu-container">
            <ul class="nav navbar-nav" id="main-menu-navigation" data-menu="menu-navigation">

                <?php $__currentLoopData = $menu_byidlevel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firstmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if(empty($firstmenu['children'])): ?>
                        <li data-menu="" class="<?php if(Request::is($firstmenu['link']) || Request::is($firstmenu['link'] . '/*')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(url($firstmenu['link'])); ?>" data-i18n="<?php echo e($firstmenu['name']); ?>"><i class="<?php echo e($firstmenu['icon']); ?>"></i><?php echo e($firstmenu['name']); ?></a>
                        </li>
                    <?php else: ?>
                        <li class="dropdown nav-item" data-menu="dropdown">
                            <a class="dropdown-toggle nav-link" href="<?php echo e(url($firstmenu['link'])); ?>" data-toggle="dropdown"><i class="<?php echo e($firstmenu['icon']); ?>"></i><span data-i18n="<?php echo e($firstmenu['name']); ?>"><?php echo e($firstmenu['name']); ?></span></a>
                            <ul class="dropdown-menu">
                                
                                <?php $__currentLoopData = $firstmenu['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(empty($secondmenu['children'])): ?>
                                        <li data-menu="" class="<?php if(Request::is($secondmenu['link']) || Request::is($secondmenu['link'] . '/*')): ?> active <?php endif; ?>">
                                            <a class="dropdown-item" href="<?php echo e(url($secondmenu['link'])); ?>" data-toggle="dropdown" data-i18n="<?php echo e($secondmenu['name']); ?>"><i class="<?php echo e($secondmenu['icon']); ?>"></i><?php echo e($secondmenu['name']); ?></a>
                                        </li>
                                    <?php else: ?>
                                        <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu">
                                            <a class="dropdown-item dropdown-toggle" href="<?php echo e(url($secondmenu['link'])); ?>" data-toggle="dropdown" data-i18n="<?php echo e($secondmenu['name']); ?>"><i class="<?php echo e($secondmenu['icon']); ?>"></i><?php echo e($secondmenu['name']); ?></a>
                                            <ul class="dropdown-menu">
                                                
                                                <?php $__currentLoopData = $secondmenu['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thirdmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(empty($thirdmenu['children'])): ?>
                                                        <li data-menu="" class="<?php if(Request::is($thirdmenu['link']) || Request::is($thirdmenu['link'] . '/*')): ?> active <?php endif; ?>">
                                                            <a class="dropdown-item" href="<?php echo e(url($thirdmenu['link'])); ?>" data-toggle="dropdown" data-i18n="<?php echo e($thirdmenu['name']); ?>"><i class="<?php echo e($thirdmenu['icon']); ?>"></i><?php echo e($thirdmenu['name']); ?></a>
                                                        </li>
                                                    <?php else: ?>
                                                        <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu">
                                                            <a class="dropdown-item dropdown-toggle" href="<?php echo e(url($thirdmenu['link'])); ?>" data-toggle="dropdown" data-i18n="<?php echo e($thirdmenu['name']); ?>"><i class="<?php echo e($thirdmenu['icon']); ?>"></i><?php echo e($thirdmenu['name']); ?></a>
                                                            <ul class="dropdown-menu">
                                                                
                                                                <?php $__currentLoopData = $thirdmenu['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fourthmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if(empty($fourthmenu['children'])): ?>
                                                                        <li data-menu="" class="<?php if(Request::is($thirdmenu['link']) || Request::is($thirdmenu['link'] . '/*')): ?> active <?php endif; ?>">
                                                                            <a class="dropdown-item" href="<?php echo e(url($fourthmenu['link'])); ?>" data-toggle="dropdown" data-i18n="<?php echo e($fourthmenu['name']); ?>"><i class="<?php echo e($fourthmenu['icon']); ?>"></i><?php echo e($fourthmenu['name']); ?></a>
                                                                        </li>
                                                                    <?php else: ?>
                                                                        
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        </li>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
        </div>

    </div>
</div>
<?php /**PATH D:\@TRA\projects\taskschedule\resources\views/layouts/home/mainmenu.blade.php ENDPATH**/ ?>
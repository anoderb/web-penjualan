<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Page')); ?> <?php echo e($title ? ' - ' . $title : ''); ?></title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>adminlte3-template/plugins/fontawesome-free/css/all.min.css">

    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>adminlte3-template/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>adminlte3-template/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>adminlte3-template/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>adminlte3-template/dist/css/adminlte.min.css">

    <!-- summernote -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>adminlte3-template/plugins/summernote/summernote-bs4.min.css">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/bootstrap-icons/font/bootstrap-icons.css">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/')); ?>assets/css/my-style.css">

    <!-- Scripts -->
    

    <?php echo $__env->yieldContent('style'); ?>

    <style>
        @media print {
            @page {
                size: landscape;
            }
        }
    </style>
</head>

<body class="hold-transition sidebar-mini">
    <div id="app">
        <!-- Site wrapper -->
        <div class="wrapper">
            <div class="content-wrappe">
                <div class="container-fluid p-4">
                    <div class="d-flex justify-content-center align-items-center gap-5">
                        <img src="<?php echo e(asset('assets/images/shj.png')); ?>" alt="" width="110">
                        <div class="text-center">
                            <h3><?php echo e(strtoupper($title)); ?></h3>
                            <h3>CV SATRIA HENDRA JAYA</h3>
                        </div>
                    </div>

                    <div class="mt-3 mb-3">
                        <?php
                        // Mendapatkan bulan saat ini dan tahun saat ini
                        $currentMonth = date('F');
                        $currentYear = date('Y');
                        // Mengurangi satu bulan dari tanggal saat ini
                        $previousMonth = date('F', strtotime('-1 month'));
                        // Menampilkan periode
                        echo "<h5>Periode: $previousMonth $currentYear - $currentMonth $currentYear</h5>";
                        ?>
                    </div>

                    <?php $i = 1; ?>
                    <?php $__currentLoopData = $purchasings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchasing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="table-responsive">
                            <table id="" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th style="width: 1%">No</th>
                                        <th>No Faktur</th>
                                        <th>Nama Pemasok</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="align-top"><?php echo e($i++); ?></td>
                                        <td class="text-nowrap align-top">
                                            <?php echo e($purchasing->no_invoice); ?>

                                        </td>
                                        <td class="text-nowrap align-top">
                                            <?php echo e($purchasing->supplier->supplier_name); ?>

                                        </td>
                                        <td class="text-nowrap align-top">
                                            Rp. <?php echo e(number_format($purchasing->total)); ?>

                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="row mb-5">
                            <div class="col-1"></div>
                            <div class="col-11">
                                <div class="table-responsive">
                                    <table id="" class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th style="width: 1%">No</th>
                                                <th>Kode Produk</th>
                                                <th>Satuan</th>
                                                <th>Harga Beli</th>
                                                <th>QTY Beli</th>
                                                <th>Sub Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $j = 1; ?>
                                            <?php $__currentLoopData = $purchasing_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchasing_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($purchasing_detail->id_purchasing == $purchasing->id_purchasing): ?>
                                                    <tr>
                                                        <td class="align-top"><?php echo e($j++); ?></td>
                                                        <td class="text-nowrap align-top">
                                                            <?php echo e($purchasing_detail->product->product_code . ' - ' . $purchasing_detail->product->product_name); ?>

                                                        </td>
                                                        <td class="text-nowrap align-top">
                                                            <?php echo e($purchasing_detail->product->unit); ?>

                                                        </td>
                                                        <td class="text-nowrap align-top">
                                                            <?php echo e($purchasing_detail->price_purchase); ?>

                                                        </td>
                                                        <td class="text-nowrap align-top">
                                                            <?php echo e($purchasing_detail->qty_purchase); ?>

                                                        </td>
                                                        <td class="text-nowrap align-top">
                                                            Rp. <?php echo e(number_format($purchasing_detail->subtotal_purchase)); ?>

                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="mt-3">
                        <div class="row">
                            <div class="col-10"></div>
                            <div class="col-2">
                                <div class="text-center">
                                    <h6 class="text-nowrap">Pekanbaru, <?php echo e(date('d F Y')); ?></h6>
                                    <h6 class="mt-5"><?php echo e(Auth::user()->name); ?></h6>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
        <!-- ./wrapper -->
    </div>

    <!-- jQuery -->
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables  & Plugins -->
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/jszip/jszip.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/pdfmake/pdfmake.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/pdfmake/vfs_fonts.js"></script>
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/dist/js/adminlte.min.js"></script>

    <!-- Summernote -->
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/plugins/summernote/summernote-bs4.min.js"></script>

    <!-- AdminLTE for demo purposes -->
    <script src="<?php echo e(asset('/')); ?>adminlte3-template/dist/js/demo.js"></script>

    <script src="<?php echo e(asset('/')); ?>assets/js/my-script.js"></script>

    <?php echo $__env->yieldContent('script'); ?>

    <script>
        window.onload = function() {
            // window.print();
        };
    </script>
</body>
<!-- END: Body-->

</html>
<?php /**PATH C:\Users\User\Downloads\joki web penjualan\web penjualan\resources\views/report/V_report_purchasing.blade.php ENDPATH**/ ?>
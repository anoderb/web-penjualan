<div class="modal fade text-left" id="deletetModal<?php echo e($product->id_product); ?>" tabindex="-1" role="dialog" aria-labelledby="deletetModalLabel<?php echo e($product->id_product); ?>" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="deletetModalLabel<?php echo e($product->id_product); ?>">Hapus Data</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5>Apakah Anda yakin ingin menghapus data ini?</h5>
                <p>Jika iya, pilih 'Hapus' untuk menghapus data.</p>
            </div>
            <div class="modal-footer">
                <form action="<?php echo e(route('product_destroy', $product->id_product)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\User\Downloads\joki web penjualan\web penjualan\resources\views/product/V_product_delete.blade.php ENDPATH**/ ?>
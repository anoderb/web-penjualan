<div class="horizontal-menu-wrapper">
    <div class="header-navbar navbar-expand-sm navbar navbar-horizontal floating-nav navbar-light navbar-without-dd-arrow navbar-shadow menu-border" role="navigation" data-menu="menu-wrapper">
        <div class="navbar-header">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item mr-auto"><a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('/')); ?>assets/images/icon/logo.png" alt="" width="45">
                        <h2 class="brand-text mb-0">DGift Jambi</h2>
                    </a></li>
                <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i class="feather icon-x d-block d-xl-none font-medium-4 primary toggle-icon"></i><i class="toggle-icon feather icon-disc font-medium-4 d-none d-xl-block collapse-toggle-icon primary"
                            data-ticon="icon-disc"></i></a></li>
            </ul>
        </div>

        <!-- Horizontal menu content-->
        <div class="navbar-container main-menu-content" data-menu="menu-container">
            <ul class="nav navbar-nav" id="main-menu-navigation" data-menu="menu-navigation">
                <?php $__currentLoopData = $menu_byidlevel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firstmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="dropdown dropdown-submenu <?php if(Request::is($firstmenu['link']) || Request::is($firstmenu['link'] . '/*')): ?> active <?php endif; ?>" data-menu="dropdown-submenu">
                        <?php if(!empty($firstmenu['children'])): ?>
                            <a class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown">
                            <?php else: ?>
                                <a class="dropdown-item" href="<?php echo e(url($firstmenu['link'])); ?>">
                        <?php endif; ?>
                        <i class="<?php echo e($firstmenu['icon']); ?>"></i>
                        <span><?php echo e($firstmenu['name']); ?></span>
                        </a>
                        <?php if(!empty($firstmenu['children'])): ?>
                            <ul class="dropdown-menu">
                                <?php $__currentLoopData = $firstmenu['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="dropdown dropdown-submenu <?php if(Request::is($secondmenu['link']) || Request::is($secondmenu['link'] . '/*')): ?> active <?php endif; ?>" data-menu="dropdown-submenu">
                                        <?php if(!empty($secondmenu['children'])): ?>
                                            <a class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown">
                                            <?php else: ?>
                                                <a class="dropdown-item" href="<?php echo e(url($secondmenu['link'])); ?>">
                                        <?php endif; ?>
                                        <i class="<?php echo e($secondmenu['icon']); ?>"></i>
                                        <span><?php echo e($secondmenu['name']); ?></span>
                                        </a>
                                        <?php if(!empty($secondmenu['children'])): ?>
                                            <ul class="dropdown-menu">
                                                <?php $__currentLoopData = $secondmenu['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thirdmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="dropdown dropdown-submenu <?php if(Request::is($thirdmenu['link']) || Request::is($thirdmenu['link'] . '/*')): ?> active <?php endif; ?>" data-menu="dropdown-submenu">
                                                        <?php if(!empty($thirdmenu['children'])): ?>
                                                            <a class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown">
                                                            <?php else: ?>
                                                                <a class="dropdown-item" href="<?php echo e(url($thirdmenu['link'])); ?>">
                                                        <?php endif; ?>
                                                        <i class="<?php echo e($thirdmenu['icon']); ?>"></i>
                                                        <span><?php echo e($thirdmenu['name']); ?></span>
                                                        </a>
                                                        <?php if(!empty($thirdmenu['children'])): ?>
                                                            <ul class="dropdown-menu">
                                                                <?php $__currentLoopData = $thirdmenu['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fourthmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li data-menu="">
                                                                        <a class="dropdown-item <?php if(Request::is($fourthmenu['link']) || Request::is($fourthmenu['link'] . '/*')): ?> active <?php endif; ?>" href="<?php echo e(url($fourthmenu['link'])); ?>">
                                                                            <i class="<?php echo e($fourthmenu['icon']); ?>"></i>
                                                                            <span><?php echo e($fourthmenu['name']); ?></span>
                                                                        </a>
                                                                    </li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        <?php endif; ?>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

    </div>
</div>
<?php /**PATH C:\Users\User\Desktop\web dgift\resources\views/layouts/home/mainmenu.blade.php ENDPATH**/ ?>
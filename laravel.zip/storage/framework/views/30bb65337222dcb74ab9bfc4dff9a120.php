<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo e($title); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="card">
                    <div class="card-header">
                        <a href="<?php echo e(route('product_create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i>&nbsp; Tambah Data</a>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <?php if(session('success') || session('error')): ?>
                            <div class="alert  alert-<?php echo e(session('success') ? 'success' : 'danger'); ?> alert-dismissible fade show" role="alert">
                                <p class="mb-0"><?php echo e(session('success') ? session('success') : session('error')); ?></p>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true"><i class="feather icon-x-circle"></i></span>
                                </button>
                            </div>
                        <?php endif; ?>
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Foto Produk</th>
                                    <th>Kode Produk</th>
                                    <th>Nama Produk</th>
                                    <th>Kategori</th>
                                    <th>QTY</th>
                                    <th>Satuan</th>
                                    <th>Harga Jual</th>
                                    <th>Diskon</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="align-top"><?php echo e($i++); ?></td>
                                        <td class="text-nowrap align-top">
                                            <a href="<?php echo e(asset('/assets/images/product/' . $product->product_photo)); ?>" target="_blank">
                                                <img src="<?php echo e(asset('/assets/images/product/' . $product->product_photo)); ?>" alt="" class="img-thumbnail">
                                            </a>
                                        </td>
                                        <td class="text-nowrap align-top">
                                            <?php echo e($product->product_code); ?>

                                        </td>
                                        <td class="text-nowrap align-top">
                                            <?php echo e($product->product_name); ?>

                                        </td>
                                        <td class="text-nowrap align-top">
                                            <?php echo e($product->category->category_name); ?>

                                        </td>
                                        <td class="text-nowrap align-top">
                                            <?php echo e($product->qty); ?>

                                        </td>
                                        <td class="text-nowrap align-top">
                                            <?php echo e($product->unit); ?>

                                        </td>
                                        <td class="text-nowrap align-top">
                                            Rp. <?php echo e(number_format($product->price_sale)); ?>

                                        </td>
                                        <td class="text-nowrap align-top">
                                            Rp. <?php echo e(number_format($product->discount)); ?>

                                        </td>
                                        <td class="align-top btn-group">
                                            <a href="<?php echo e(route('product_edit', $product->id_product)); ?>" class="btn btn-warning"><i class="fas fa-edit"></i></a>
                                            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deletetModal<?php echo e($product->id_product); ?>"><i class="fas fa-trash"></i></button>
                                        </td>
                                        <?php echo $__env->make('product.V_product_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .img-thumbnail {
            width: 60px;
            height: 60px;
            background-position: center;
            background-repeat: no-repeat;
            background-size: contain;
            object-fit: cover;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\other\web-penjualan\resources\views/product/V_product.blade.php ENDPATH**/ ?>
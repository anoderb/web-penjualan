<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo e($title); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/purchasing')); ?>">
                                    Pembelian</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="no_invoice">No Faktur</label>
                                    <input type="text" name="no_invoice" id="no_invoice" value="<?php echo e($purchasing->no_invoice); ?>" class="form-control no_invoice" placeholder="No Faktur" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="id_supplier">Nama Pemasok</label>
                                    <input type="text" name="id_supplier" id="id_supplier" value="<?php echo e($purchasing->supplier->supplier_name); ?>" class="form-control id_supplier <?php $__errorArgs = ['id_supplier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Nama Pemasok" readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Total</label>
                                    <div class="card bg-success">
                                        <div class="card-body">
                                            <h1>Rp. <?php echo e(number_format($purchasing->total)); ?></h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr>
                        <?php if(session('success') || session('error')): ?>
                            <div class="alert  alert-<?php echo e(session('success') ? 'success' : 'danger'); ?> alert-dismissible fade show" role="alert">
                                <p class="mb-0"><?php echo e(session('success') ? session('success') : session('error')); ?></p>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true"><i class="feather icon-x-circle"></i></span>
                                </button>
                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('store_purchasing_detail', $purchasing->id_purchasing)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="id_product">Kode Produk</label>
                                        <select name="id_product" id="id_product" class="form-control select2 id_product <?php $__errorArgs = ['id_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="">- pilih -</option>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $value = implode(',', [$product->id_product, $product->qty, $product->unit]); ?>
                                                <option value="<?php echo e($product->id_product . ',' . $product->qty . ',' . $product->unit); ?>" <?php echo e($product->id_product . ',' . $product->qty . ',' . $product->unit == old('id_product') ? 'selected' : ''); ?>>
                                                    <?php echo e($product->product_code . ' - ' . $product->product_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['id_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="qty">Stok Lama</label>
                                        <input type="number" name="qty" id="qty" value="<?php echo e(old('qty')); ?>" class="form-control qty <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" readonly>
                                        <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="unit">Satuan</label>
                                        <input type="text" name="unit" id="unit" value="<?php echo e(old('unit')); ?>" class="form-control unit <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" readonly>
                                        <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="price_purchase">Harga Beli</label>
                                        <input type="number" name="price_purchase" id="price_purchase" value="<?php echo e(old('price_purchase')); ?>" class="form-control price_purchase <?php $__errorArgs = ['price_purchase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <?php $__errorArgs = ['price_purchase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="qty_purchase">QTY Beli</label>
                                        <input type="number" name="qty_purchase" id="qty_purchase" value="<?php echo e(old('qty_purchase')); ?>" class="form-control qty_purchase <?php $__errorArgs = ['qty_purchase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <?php $__errorArgs = ['qty_purchase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="subtotal_purchase">Sub Total</label>
                                        <input type="number" name="subtotal_purchase" id="subtotal_purchase" value="<?php echo e(old('subtotal_purchase')); ?>" class="form-control subtotal_purchase <?php $__errorArgs = ['subtotal_purchase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" readonly>
                                        <?php $__errorArgs = ['subtotal_purchase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">Tambah Pembelian</button>
                        </form>

                        <br>
                        <div class="table-responsive">
                            <table id="" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode Produk</th>
                                        <th>Satuan</th>
                                        <th>Harga Beli</th>
                                        <th>QTY Beli</th>
                                        <th>Sub Total</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $purchasing_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchasing_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="align-top"><?php echo e($i++); ?></td>
                                            <td class="text-nowrap align-top">
                                                <?php echo e($purchasing_detail->product->product_code . ' - ' . $purchasing_detail->product->product_name); ?>

                                            </td>
                                            <td class="text-nowrap align-top">
                                                <?php echo e($purchasing_detail->product->unit); ?>

                                            </td>
                                            <td class="text-nowrap align-top">
                                                <?php echo e($purchasing_detail->price_purchase); ?>

                                            </td>
                                            <td class="text-nowrap align-top">
                                                <?php echo e($purchasing_detail->qty_purchase); ?>

                                            </td>
                                            <td class="text-nowrap align-top">
                                                Rp. <?php echo e(number_format($purchasing_detail->subtotal_purchase)); ?>

                                            </td>
                                            <td class="align-top btn-group">
                                                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deletepurchasingdetailtModal<?php echo e($purchasing_detail->id_purchasing_detail); ?>"><i class="fas fa-trash"></i></button>

                                                <div class="modal fade text-left" id="deletepurchasingdetailtModal<?php echo e($purchasing_detail->id_purchasing_detail); ?>" tabindex="-1" role="dialog" aria-labelledby="deletepurchasingdetailtModalLabel<?php echo e($purchasing_detail->id_purchasing_detail); ?>"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-scrollable" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title" id="deletepurchasingdetailtModalLabel<?php echo e($purchasing_detail->id_purchasing_detail); ?>">Hapus Data</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <h5>Apakah Anda yakin ingin menghapus data ini?</h5>
                                                                <p>Jika iya, pilih 'Hapus' untuk menghapus data.</p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <form action="<?php echo e(route('destroy_purchasing_detail', ['id' => $purchasing_detail->id_purchasing_detail, 'id_purchasing' => $purchasing->id_purchasing])); ?>" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button type="submit" class="btn btn-danger">Hapus</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
                <!-- /.card -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('#id_product').change(function() {
                var selectedValue = $(this).val();
                if (selectedValue) {
                    var values = selectedValue.split(',');
                    $('#qty').val(values[1]);
                    $('#unit').val(values[2]);
                } else {
                    $('#qty').val('');
                    $('#unit').val('');
                }
            });

            // Fungsi untuk menghitung subtotal
            function calculateSubtotal() {
                var pricePurchase = parseFloat($('#price_purchase').val()) || 0;
                var qtyPurchase = parseFloat($('#qty_purchase').val()) || 0;
                var subtotal = pricePurchase * qtyPurchase;
                $('#subtotal_purchase').val(subtotal);
            }

            // Event listener untuk perubahan pada input harga beli dan kuantitas beli
            $('#price_purchase, #qty_purchase').on('input', function() {
                calculateSubtotal();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Downloads\joki web penjualan\web penjualan\resources\views/purchasing/V_purchasing_edit.blade.php ENDPATH**/ ?>
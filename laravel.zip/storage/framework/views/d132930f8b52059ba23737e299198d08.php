<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 3.2.0
    </div>
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="<?php echo e(url('/')); ?>">App</a>.</strong> All rights reserved.
</footer>
<?php /**PATH C:\other\web-penjualan\resources\views/layouts/home/footer.blade.php ENDPATH**/ ?>